TANI CERDAS - WEBSITE DEMO LENGKAP

CARA MENJALANKAN
1. Ekstrak ZIP, buka folder tani_cerdas_login.
2. Klik dua kali index.html. Tidak perlu internet (tanpa font/foto eksternal).

AKUN DEMO
Email: demo@tanicerdas.id | Kata sandi: tani123

YANG BISA DIKLIK
- Kartu Fitur -> membuka alat terkait; kartu Komoditas -> detail tanaman (umur, jarak tanam, pH, hama, tips).
- Masuk, Daftar, Atur ulang kata sandi (demo lokal), Dashboard.
- Dashboard: kalkulator pupuk (pilihan Urea/ZA/SP-36/KCl/NPK), perkecambahan, populasi tanaman & benih,
  catatan budidaya (hapus), jadwal & pengingat, ruang konsultasi (salin / WhatsApp), data saya (CSV, cadangan JSON, pulihkan, hapus).
- Kamus istilah tani (bisa dicari) dan formulir kontak.

AKSESIBILITAS & DISLEKSIA (tombol "Akses & baca" di kanan bawah)
Preset disleksia 1 klik, jenis huruf (Verdana, Comic Sans, ramah disleksia), ukuran teks sampai ekstra besar,
jarak huruf/kata/baris, kolom sempit, warna latar krem/kuning/biru/kontras tinggi, penggaris baca,
bacakan teks (suara), sembunyikan hiasan, garis bawah tautan, kurangi animasi. Pengaturan tersimpan otomatis.

KEAMANAN
Ini prototipe frontend. Data di localStorage browser; kata sandi akun baru di-hash SHA-256 tetapi tetap BELUM
cukup aman untuk data nyata. Untuk produksi, gunakan backend autentikasi (Supabase/Firebase).
Kalkulator pupuk hanya alat bantu hitung; ikuti analisis tanah dan rekomendasi penyuluh setempat.
